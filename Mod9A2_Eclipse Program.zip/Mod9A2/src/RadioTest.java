
public class RadioTest {

	public static void main(String[] args) {
		//  Create two new radios
	   Radio myRadio = new Radio();
	   Radio carRadio = new Radio();
	   
	   // set settings for radio 1
	   myRadio.turnOn();
	   myRadio.selectFM();
	   myRadio.setFreq(93.5);
	   myRadio.setVol(5);
	   
	   // set settings for radio 2
	   carRadio.turnOn(); 
	   carRadio.selectAM();
	   // turn the frequency up until it gets to 720
	   while(carRadio.getFreq() < 720) {
		   carRadio.freqUp();
	      }
	   
	   carRadio.volUp();
	   
	   
	   
	   
	   System.out.println("Radio 1's band is " + myRadio.getBand() + " set to station " + myRadio.getFreq() + " and volume level is " + myRadio.getVol());
       System.out.println("Radio 2's band is " + carRadio.getBand() + " set to station " + carRadio.getFreq() + " and the volume level is " + carRadio.getVol());
	}

}
