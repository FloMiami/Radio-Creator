
public class Radio {
// data fields
String band; 
double frequency;
int volume;
boolean power;
//methods
Radio(){	

band = "AM";
power = false;
volume = 1;
frequency = 540;


}

String getBand() {
  return band;
}

double getFreq() {
	return frequency;
}

int getVol() {
	return volume;
}

void turnOn() {
	power = true;
}

void turnOff() {
	power = false;
}

void selectAM() {
	band = "AM";
	//ensure the frequency is within the AM band
	if (frequency < 540) {
		frequency = 540;
	}else if (frequency > 1700 ) {
		frequency = 1700;
	}
}

void selectFM() {
	band = "FM";
	//ensure the frequency is within the FM band
	if (frequency < 88) {
		frequency = 88;
	}else if (frequency > 108.0) {
		frequency = 108.0;
		
	}
	
}

void setFreq(double newFreq) {
	//check the power before changing the frequency
	if (power) {
	frequency = newFreq;
	
	if(band.equals("AM")) {
		//Ensure that the frequency is within the AM Band Range
		if(frequency <540 ) {
			frequency = 540;
		}
		else if(frequency > 1700) {
			frequency = 1700;
		}
		
	 
	} else if (band.equals("FM")) {
		//Ensure the frequency is within the FM Band Range
		if(frequency < 88.0) {
			frequency = 88.0;
		}

		else if (frequency > 108.0) {
			frequency = 108.0;
			
		}
	 }
	
  }
}
	

void setVol(int newVol) {
	//check the power status before changing the volume
	if (power) {
	volume = newVol;
	}
}

void freqUp() {
	if(power) {
		if(band.equals("AM")) {
			frequency += 10; //Increment by 10 kHz for the AM Band
		if(frequency > 1700) {
			frequency = 540; // Wrap around if it goes above the AM Band
		}
	}
	
		else if (band.equals("FM")) {
			frequency += 0.2; //Increment by 0.2 MHz for FM Band
			if(frequency > 108.0) {
				frequency = 88;  // Wrap around if it goes above the FM Band
			}
		}
	
	}
}

void freqDown() {
	//check the power status before decrementing the frequency
	if(power) {
		if(band.equals("AM")) {
			frequency -= 10; // Decrement by 10 kHz for AM Band
		if(frequency < 540) {
			frequency = 1700; // Wrap around if it goes below the AM Band
		}
	} else if (band.equals("FM")) {
		frequency -= 0.2; // Decrement by 0.2 MHz for FM Band
		if (frequency < 88) {
			frequency = 108.0; // Wrap around if it goes below the FM band
		   }
	     }
      }
	
    }
	 


void volUp() {
	//check the power status before changing the volume 
	if (power) {
		volume++;
	}
}
void volDown() {
	//check the power status before changing the volume
	if (power) {
		volume--;
	}

   }

}
